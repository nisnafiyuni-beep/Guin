# Instruksi untuk Claude AI — Guinevere Auto Free

Baca seluruh source project Android di folder `GuinevereAutoFree` sebelum mengubah apa pun.

## Tujuan
Bantu menyelesaikan aplikasi Android Kotlin bernama **Guinevere Auto Free** untuk membantu mendeteksi label `FREE` pada lima kartu hero di shop Magic Chess: Go Go. Aplikasi yang dihasilkan harus berupa APK Android yang dapat dipasang pada Infinix Hot 50.

## Batasan dan perilaku yang wajib
- Jangan mengklaim APK berhasil dibuat sebelum benar-benar menjalankan build dan memeriksa file APK hasilnya.
- Jangan menebak koordinat layar. Buat kalibrasi/konfigurasi area toko dan validasi deteksi terlebih dahulu.
- Gunakan deteksi teks `FREE` dengan OCR atau pendekatan visi yang sesuai; bedakan label `FREE` pada kartu dari tombol `GRATIS x1` di sisi kanan.
- Tampilkan target yang terdeteksi dan minta konfirmasi pengguna sebelum interaksi otomatis.
- Sediakan tombol START dan STOP, jeda aman, pencegahan klik ganda, dan pemindaian ulang setelah tampilan shop berubah.
- Jelaskan izin Android yang diminta (screen capture / Accessibility) dan alasan penggunaannya. Jangan menyembunyikan aktivitas atau melewati proteksi game.
- Periksa aturan layanan game dan jangan menerapkan teknik yang menghindari anti-cheat atau proteksi keamanan.
- Pastikan layanan berhenti saat pengguna menekan STOP atau menutup sesi.

## Tugas teknis
1. Audit Gradle, AndroidManifest, Kotlin, resource, dan konfigurasi SDK.
2. Perbaiki error kompilasi dan dependensi yang benar-benar diperlukan.
3. Pastikan target SDK dan minimum SDK sesuai dengan perangkat Android modern.
4. Buat UI sederhana dengan status deteksi, jumlah kartu FREE, START/STOP, dan petunjuk izin.
5. Tambahkan README berisi cara build.
6. Jalankan `./gradlew assembleDebug` (atau perintah build yang sesuai dengan wrapper yang tersedia).
7. Jika build berhasil, tunjukkan path APK debug yang benar, biasanya `app/build/outputs/apk/debug/app-debug.apk`.
8. Jika tidak dapat menjalankan Android SDK/Gradle di lingkungan yang tersedia, jangan berpura-pura berhasil; berikan error lengkap dan langkah berikutnya.

## Output yang diminta
- Source project yang sudah diperbaiki.
- APK hanya jika benar-benar berhasil dikompilasi.
- Ringkasan fitur yang sudah berfungsi dan fitur yang masih berupa placeholder.
