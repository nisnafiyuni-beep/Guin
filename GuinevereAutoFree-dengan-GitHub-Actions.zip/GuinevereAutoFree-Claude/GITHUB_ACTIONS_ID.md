# Build APK melalui GitHub Actions (tanpa PC untuk proses build)

Workflow sudah disediakan di `.github/workflows/build-apk.yml`.

1. Buat repository GitHub baru dan upload seluruh isi folder `GuinevereAutoFree-Claude` ke repository (jangan upload ZIP sebagai satu file; ekstrak dahulu).
2. Pastikan folder `GuinevereAutoFree` dan folder `.github/workflows` berada di tingkat teratas repository.
3. Buka tab **Actions** pada repository.
4. Pilih workflow **Build Guinevere Auto Free APK**.
5. Tekan **Run workflow** lalu konfirmasi **Run workflow**.
6. Tunggu sampai job selesai. Jika berhasil, buka run tersebut, cari bagian **Artifacts**, lalu unduh `GuinevereAutoFree-debug-apk`.
7. Ekstrak ZIP artifact. APK yang dihasilkan bernama `app-debug.apk`.

Jika gagal, buka job **build** dan salin bagian log error merah untuk diperiksa. Workflow ini baru mengotomatiskan proses build; keberhasilan belum dapat dipastikan sebelum dijalankan di GitHub.

## Peringatan penting tentang source saat ini

Source saat ini masih prototipe. `FreeScanService.kt` menjalankan ketukan otomatis ketika OCR menemukan teks `FREE`; belum ada layar pratinjau target atau konfirmasi pengguna sebelum ketukan. Koordinat ketukan juga dihitung dari posisi teks dengan perkiraan tetap. Karena itu, jangan aktifkan layanan klik otomatis pada akun/game utama sebelum perilaku tersebut diperbaiki dan diuji. Workflow ini tidak mengubah perilaku aplikasi dan tidak menghindari anti-cheat atau proteksi game.
